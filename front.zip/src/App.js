import React, {Component} from 'react';
import Navbar from './components/Navbar';
//import image from './components/images/';

//import api from '/Projeto_Adega/adegazeratao/src/api';

// const app = express();

// app.use(express.json());

class App extends Component{

        constructor(props){
            super(props);
            this.state = {
                Detalhes : [],
                Cervejas : [],
            };
            this.listaDetalhes = this.listaDetalhes.bind(this);
        }

        listaDetalhes() {
            
            fetch('https://localhost:44389/DeatlhesCerveja/ativos').then((r) => r.json())
            .then((json) => {
                let state = this.state;
                state.Detalhes = json;
                this.setState(state)
            })
            
        }
       

        componentDidMount(){
                   
            //const response = api.get(`/ativos`);
                
            fetch('https://localhost:44389/Cerveja/ativos').then((r) => r.json())
            .then((json) => {
                let state = this.state;
                state.Cervejas = json;
                this.setState(state);

            })
       
                
        }
          
        render(){

            return(
      
                <div>
                    <h1 className="text-app">ADEGA ZE RATÃO API</h1>
                    <Navbar />
                    <div className="pt-1">
                        <div className="row col-md-11">
                            {this.state.Cervejas.map((Cerveja) => {
                                return(
                                    <a key= {Cerveja.idCerveja} className="col-2">
                                        <img src={Cerveja.foto} className="img-foto"/> 
                                        <p className="text-cerv">Descrição : {Cerveja.descricao}</p> 
                                        <p className="text-cerv">Tipo : {Cerveja.tipo}</p> 
                                        <p className="text-cerv">Categoriga : {Cerveja.categoria}</p> 
                                           
                                        
                                    </a>
                                    
                                );
                            })}
                        </div>
                        <div className="container col-2 pt-8">
                            <button onClick={this.listaDetalhes} className="button">Listar Detalhes</button>
                        </div>
                        <div class="container col-5 pt-4">
                            {this.state.Detalhes.map((Detalhe) => {
                                return(
                                    <article key= {Detalhe.idDetalhe}>
                                        <p>{Detalhe.ranking}</p>
                                        <p>{Detalhe.tipo}</p>
                                        <p>{Detalhe.produtoQuantidade}</p>  
                                        <p>{Detalhe.precoSugerido}</p>  

                                    </article>
                                );
                            })}
                        </div>
                    </div>
                </div>
                
            );
        };
    };

export default App;