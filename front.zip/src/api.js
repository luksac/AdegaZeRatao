import axios from 'axios';





const api = axios.create({
    baseURL :  `https://localhost:44389/DeatlhesCerveja/`,
    headers: {
                        'Content-Type': 'application/json' ,
                        'Origin': 'XMLHttpRequest', 
                        //'Access-Control-Allow-Origin': '*' ,
                        //'Access-Control-Allow-Headers':'origin, content-type, accept, authorization'
        // 'Host' : 'localhost: 44389',
        // 'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0',
     
        //'Access-Control-Request-Method' : 'GET',
        //'Access-Control-Allow-Headers' : 'Access-Control-Allow-Headers',
        //'Access-Control-Request-Headers' : 'Access-Control-Allow-Headers'
       
        // // Referer: http://localhost:3000/
        // // Origin: http://localhost:3000

        // 'Content-Type': 'application/json',
        // 'Accept': 'application/json',
        // 'Access-Control-Request-Headers' : '' ,
        // 'Content-Type' : '',
        // 'Access-Control-Allow-Origin' : '',
        // 'Access-Control-Request-Origin' : 'http://localhost:3000',
        // 'Access-Control-Request-Origin' : 'Access-Control-Request-Origin',
        // 'Access-Control-Request-Origin' : 'Access-Control-Request-Origin'

       
        // Host: localhost:44389
        // User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0
        // Accept: */*
        // Accept-Language: pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3
        // Accept-Encoding: gzip, deflate, br
        // Access-Control-Request-Method: GET
        // Access-Control-Request-Headers: access-control-allow-headerscontent,access-control-allow-origin
        // Referer: http://localhost:3000/
        // Origin: http://localhost:3000
        // Connection: keep-alive
    }
});



export default api;

